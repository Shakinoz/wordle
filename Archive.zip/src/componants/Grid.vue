<script setup>
import { ref, onMounted, onUnmounted } from "vue";
import Letter from "./Letter.vue";
import { isValidWord } from "../isValidWord.js";

const props = defineProps({
    disabledLetters: {
        type: Object,
        default: () => ({}),
    },
    letterStatuses: {
        type: Object,
        default: () => ({}),
    },
});

const emit = defineEmits([
    "win",
    "lose",
    "letterStatuses",
    "restoreLetterStatuses",
]);

const currentRow = ref(0);
const currentCol = ref(0);
const gameOver = ref(false);
const shakeRow = ref(-1);

const rows = ref([
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
    Array.from({ length: 5 }, () => ({ value: "", status: "empty" })),
]);

const STORAGE_KEY = "wordle-progress";

function saveProgress(letterStatuses) {
    const secretWord = localStorage.getItem("wordle-word");
    const progress = {
        word: secretWord,
        rows: rows.value,
        currentRow: currentRow.value,
        currentCol: currentCol.value,
        letterStatuses: letterStatuses,
        gameOver: gameOver.value,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
}

function loadProgress() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return false;

    try {
        const progress = JSON.parse(saved);
        const currentWord = localStorage.getItem("wordle-word");

        if (progress.word !== currentWord) {
            localStorage.removeItem(STORAGE_KEY);
            return false;
        }

        rows.value = progress.rows;
        currentRow.value = progress.currentRow;
        currentCol.value = progress.currentCol;
        gameOver.value = progress.gameOver || false;

        if (progress.letterStatuses) {
            emit("restoreLetterStatuses", progress.letterStatuses);
        }

        return true;
    } catch (e) {
        console.error("Erreur lors du chargement de la progression:", e);
        localStorage.removeItem(STORAGE_KEY);
        return false;
    }
}

onMounted(() => {
    loadProgress();
    window.addEventListener("keydown", handleKey);
});

onUnmounted(() => {
    window.removeEventListener("keydown", handleKey);
});

function isLetterDisabled(letter) {
    const upperLetter = letter.toUpperCase();
    return props.disabledLetters[upperLetter] === "absent";
}

function handleKey(e) {
    if (gameOver.value) return;

    if (e.key.match(/^[a-zA-Z]$/)) {
        addLetter(e.key);
    }

    if (e.key === "Backspace") {
        deleteLetter();
    }

    if (e.key === "Enter") {
        submitWord();
    }
}

function addLetter(letter) {
    if (currentCol.value < 5) {
        rows.value[currentRow.value][currentCol.value].value = letter;
        currentCol.value++;
    }
}

function deleteLetter() {
    if (currentCol.value > 0) {
        currentCol.value--;
        rows.value[currentRow.value][currentCol.value].value = "";
    }
}

function submitWord() {
    if (currentCol.value === 5) {
        const word = rows.value[currentRow.value].map((l) => l.value).join("");
        if (!isValidWord(word)) {
            shakeRow.value = currentRow.value;
            setTimeout(() => {
                shakeRow.value = -1;
            }, 500);
            return;
        }
        checkWord();
    }
}

function checkWord() {
    const secretWord = localStorage.getItem("wordle-word");

    if (!secretWord) {
        console.error("Aucun mot secret trouvé dans le localStorage");
        return;
    }

    const secret = secretWord.toLowerCase().split("");
    const word = rows.value[currentRow.value].map((l) => l.value.toLowerCase());

    word.forEach((letter, i) => {
        if (letter === secret[i]) {
            rows.value[currentRow.value][i].status = "correct";
            secret[i] = null;
        }
    });

    word.forEach((letter, i) => {
        if (
            rows.value[currentRow.value][i].status === "empty" &&
            secret.includes(letter)
        ) {
            rows.value[currentRow.value][i].status = "present";
            secret[secret.indexOf(letter)] = null;
        }
    });

    rows.value[currentRow.value].forEach((cell) => {
        if (cell.status === "empty") {
            cell.status = "absent";
        }
    });

    const statusPriority = { correct: 3, present: 2, absent: 1 };
    const letterStatuses = {};
    rows.value[currentRow.value].forEach((cell) => {
        const letter = cell.value.toUpperCase();
        const currentPriority = statusPriority[letterStatuses[letter]] || 0;
        const newPriority = statusPriority[cell.status] || 0;
        if (newPriority > currentPriority) {
            letterStatuses[letter] = cell.status;
        }
    });
    emit("letterStatuses", letterStatuses);

    const allLetterStatuses = { ...props.letterStatuses, ...letterStatuses };
    saveProgress(allLetterStatuses);

    const isWin = rows.value[currentRow.value].every(
        (cell) => cell.status === "correct",
    );

    if (isWin) {
        gameOver.value = true;
        emit("win", currentRow.value + 1);
        return;
    }

    currentRow.value++;
    currentCol.value = 0;

    if (currentRow.value === 6) {
        gameOver.value = true;
        emit("lose");
    }
}
</script>

<template>
    <div class="flex flex-col gap-2 items-center">
        <div
            v-for="(row, r) in rows"
            :key="r"
            class="flex gap-2"
            :class="{ 'animate-shake': shakeRow === r }"
        >
            <Letter
                v-for="(cell, c) in row"
                :key="c"
                :value="cell.value"
                :status="cell.status"
            />
        </div>
    </div>
</template>

<style scoped>
.animate-shake {
    animation: shake 0.5s ease-in-out;
}

@keyframes shake {
    0%,
    100% {
        transform: translateX(0);
    }
    20% {
        transform: translateX(-8px);
    }
    40% {
        transform: translateX(8px);
    }
    60% {
        transform: translateX(-8px);
    }
    80% {
        transform: translateX(8px);
    }
}
</style>
